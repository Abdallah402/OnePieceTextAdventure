public class Wano extends MapTile{
    public Wano(int x, int y, Item item) {
        super(x, y);
    }
}
