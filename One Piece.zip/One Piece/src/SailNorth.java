public class SailNorth extends Action{
    public SailNorth(){
        super(Method.MoveNorth, "Move North", 'n', null);
    }
}
