public class PunkHazard extends MapTile{
    public PunkHazard(int x, int y, Marine item) {
        super(x, y);
    }
}
