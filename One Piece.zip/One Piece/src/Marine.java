public class Marine extends Enemy {
    public Marine() {
        super("Marine Officer", 20, 15);
    }

}
