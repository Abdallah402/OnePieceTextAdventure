public class SailEast extends Action{
    public SailEast(){
        super(Method.MoveEast, "Move East", 'e', null);
    }
}

