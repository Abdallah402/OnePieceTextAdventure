public class EmptyIsland extends MapTile{

    public EmptyIsland(int x, int y) {
        super(x, y);
    }


    public String intro_text(){
        return "\n You find yourself on an empty island";}
}