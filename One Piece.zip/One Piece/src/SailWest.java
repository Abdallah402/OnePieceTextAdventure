public class SailWest extends Action{
    public SailWest(){
        super(Method.MoveWest, "Move West", 'w', null);
    }
}