public enum Method {
    Flee, Attack, ViewInventory, MoveEast, MoveWest, MoveSouth, MoveNorth, Sprint
}
