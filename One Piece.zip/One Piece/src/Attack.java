public class Attack extends Action {


    public Attack(){
        super(Method.Attack, "Attack", 'a', null);
    }
}
