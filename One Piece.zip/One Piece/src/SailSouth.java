public class SailSouth extends Action{
    public SailSouth(){
        super(Method.MoveSouth, "Move South", 's', null);
    }
}
