public class TreasureIsland extends MapTile{
    public TreasureIsland(int x, int y, Item item) {
        super(x, y);
    }
}
