public class Katana extends Weapon {
    public Katana(){
        super("Sword", "A Sword with some rust. Somewhat more dangerous then a dagger.",
                10, 20);
    }
    public Katana(String name, String description, int value, int damage) {
        super("Big Mace", "A Sword with some rust. Somewhat more dangerous then a dagger.",
                10, 20);
    }

}
